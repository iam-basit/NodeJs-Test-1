const router = require('express').Router()
const studentController = require('../server/student/studentController')
router.post('/student/add', studentController.add)
router.post('/student/getall', studentController.getAllData)
router.post('/student/getsingle', studentController.getSingleData)
router.post('/student/delete', studentController.deleteData)
router.post('/student/softdelete', studentController.softDelete)
router.post('/student/update', studentController.updateData)

router.post('/register/add', registerController.add)
router.post('/register/getall', registerController.getAllData)
router.post('/register/getsingle', registerController.getSingleData)
router.post('/register/delete', registerController.deleteData)
router.post('/register/softdelete', registerController.softDelete)
router.post('/register/update', registerController.updateData)

module.exports = router
