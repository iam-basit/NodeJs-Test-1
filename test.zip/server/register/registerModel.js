const mongoose = require('mongoose')

const register = new mongoose.Schema({
  studentName: { type: String, default: null },
  admissionNumber: { type: Number, default: null },
  contact: { type: Number, default: null },
  fatherName: { type: String, default: null },
  motherName: { type: String, default: null },
  status: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now() },
})

module.exports = new mongoose.model('categories', register)
